import os

OPEN_API_KEY = os.getenv('OPENAI_API_KEY')
MODEL = 'gpt-4o'
MAX_TURN = 7
MAX_TURN_10 = 10
TERMINATION_WORD = 'stop'